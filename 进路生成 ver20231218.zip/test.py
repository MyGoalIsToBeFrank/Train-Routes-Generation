# -*- coding: utf-8 -*-
"""
Created on Sat Dec  9 21:58:03 2023

@author: Duan Chuyu
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Dec  8 19:49:04 2023

@author: Duan Chuyu
"""

import networkx as nx
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

# 读取点
points = pd.read_excel('points.xlsx')
points['point'] = points['point'].apply(lambda i : str(i)) #确保名称读取为字符串
points = points.set_index('point')
# 读取边
edges = pd.read_excel('edges.xlsx')


### 创建图
G = nx.DiGraph()
for index, row in points.iterrows():
    G.add_node( index, 
                char=row['point_char'],
                x = row['point_X'],
                y = row['point_Y'])

for index, row in edges.iterrows():
    # 获取边所经过的所有道岔/角顶
    viaItems = str(row['via']).split(',')
    if(len(viaItems)==1 and viaItems[0].find('0') >= 0):
        viaItems = []
    # 根据他们的X坐标升序或降序排列，分别对应西向和东向的道岔顺序
    viaItems_east = sorted(viaItems, key = lambda i : points.loc[i,'point_X'])
    viaItems_west = sorted(viaItems, key = lambda i : points.loc[i,'point_X'], reverse = True)
    
    # 确定边的基本信息
    start = row['from']
    end = row['to']
    length_ = row['length']
    # 创建边：edges.xlsx中的边是无向图，但程序中是有向图，所以每行数据建立两条边
    # 如果无向边输入顺序是向east
    if (points.loc[start,'point_X'] < points.loc[end,'point_X']):
        G.add_edge(start, end, length = length_, via = viaItems_east, drc = 'east')
        G.add_edge(end, start, length = length_, via = viaItems_west, drc = 'west')
    # 如果无向边输入顺序时向west
    else:
        G.add_edge(start, end, length = length_, via = viaItems_west, drc = 'west')
        G.add_edge(end, start, length = length_, via = viaItems_east, drc = 'east')
